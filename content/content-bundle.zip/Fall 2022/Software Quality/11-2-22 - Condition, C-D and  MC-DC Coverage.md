- ### Condition Coverage
	- ![[Pasted image 20221102140721.png]]
	2. Condistion
	3. Decision Points
		- 1, 3, 4, 5: (TF -> FT)
		- 1, 3, 4, 5: (FT -> TF)
	4.  Predicate
		- Test case 1:
			- X > 1 && y != 0 && z != 2 && y > 1
		- Test case 2:
			- X <= 1 && Y == 0 && z == 2 && y <= 1
	5. Test case input:
| case # | X   | Y   | Z   | Expected output |
| ------ | --- | --- | --- | --------------- |
| 1      | 2   | 2   | 1   |                 |
| 2      | 1   | 0   | 2   |                 |

### Different way of Designing Test Cases
- Alternative CFG
	- ![[Pasted image 20221102141534.png]]
	- it considers the short-circuit evaluation! 
	- But for most coverage criteria, we still use the previous one! This one is only used for condition coverage.
	1.  h
	2. Edges to cover:
		1. 23 25 34 35 56 57 67 68
	3. Paths
		3. 1 ,2 ,3 ,4 ,5 ,7 ,8
		4. 1, 2, 3, 5, 6, 8
		5. 1, 2, 5, 6, 7, 8
	4. Test case inputs
| test # | X   | Y   | Z   |
| ------ | --- | --- | --- |
| 1      | 2   | 0   | 4   |
| 2      | 2   | -1  | 4   |
| 3      | -1  | 2   | 4   |
- ### Condition Coverage
	- Does condition coverage guarantee decision coverage?  
		- No. A^B: {(T,F), (F,T)}  
	- Does decision coverage guarantee condition coverage?  
		- No. A^B: {(T,T),(T,F)}
- ### Condition / Decision Coverage
	- If you use CFG considering short circuit evaluation to generate test inputs....
- ### Modified Condition / Multiple Decision coverage
	- Think about "A && B", where A, B are bool inputs
	- To satisfy CD coverage:
|        | A   | B   |
| ------ | --- | --- |
| Test 1 | T   | T   |
| Test 2 | F   | F    |
	- What's the problem?
	- Test set doesn't test B=F!
		- In test 2, A=F will mask testing B's value.

- # MC/DC Coverage
	- ### MC/DC example
		- if( kettle && cup && coffee) return cup_of_coffee;
| Test # | Kettle | Cup | Coffee |
| ------ | ------ | --- | ------ |
| 1      | T      | T   | T      |
| 2      | T      | T   | F       |
