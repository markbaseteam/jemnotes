# Exam 2 Study Guide
- ### Software Process Management 
	- ![[10 - Software Process Control]]
- ### Cause Effect Diagram
	- ![[11 - Cause-Effect Diagram]]
- ![[12 - Control Charts]]
- ![[13 - Quality Management]]
- ![[15 - QA Organization]]
- 