1. Which chart or diagram would be best for organizing/sorting issues so that we can see which issue(s) are most important to study?
	- A. Control Chart
	- B. Fishbone Diagram
	- C. [Pateto Chart]
	- D. Run Chart
	- E. Scatter Diagram
	- F. Histogram <- [I Choose]
2. Which kind of chart or diagram contains specification limits and monitors how well a process is performing?
	- A. [Control Chart]
	- B. Fishbone Diagram
	- C. Pateto Chart
	- D. Run Chart
	- E. Scatter Diagram
	- F. Histogram
3. Which type of chart diagram would be useful for determining if there is a realtionship between two variables, for instance minutes studied and quiz grade?
	- A. Control Chart
	- B. Fishbone Diagram
	- C. Pateto Chart
	- D. Run Chart
	- E. [Scatter Diagram]
	- F. Histogram
4. A software company is trying to monitor whether the amount of failure reports is stable for one software product. They collected data for 2 consecutive years. Each month, they randomly selected 8 days to record the number of failure reports submitted. Based on this sampling plan, which control chart should be used?
	- A. [X-bar chart and R chart]
	- B. X-bar chart and S chart
	- C. X-bar chart and p Chart
	- D. XmR chart
5.  Which chart do we use when we can only take single measurement within each sample>
	- A. X-bar chart and R chart <- [I Choose]
	- B. X-bar chart and S chart
	- C. X-bar chart and p Chart
	- D. [XmR chart]
6. What is/are the uses of a Fishbone diagram?
	- A. Determine if a process is under control
	- B. [Produce a canidate list of possible factors (causes) that influence a situation (effects)]
	- C. Plat to variables to look for correlations
	- D. Plot real-time data against upper and lower control and specification limit
	- E. Histogram that is sorted by frequency or importance
7. Which is the correct order of the phases of the Deming Cycle for continuous process improvement?
	- A. Define, Plan, Check, Act
	- B. Check, Plan, Develop, Act
	- C. [Plan, Do, Check, Act]
	- D. Plan, Design, Create, Act
8. Which of the following contradicts the goals of Deming's 14 Quality Principles?
	- A. Training is not important, as it takes valuable time away from development and testing.
	- B. Slogans can often times have the opposite impact if they are not well thought out
	- C. Assigning ownership of a module should be done, as people will take price in owning specific modules, and thus quality will improve
	- D. Numerical goals are a good idea, as people are driven to exceed these goals, and thus actual quality and productivity will always improve <-[ I Choose]
	- E. A & B
	- F. C & D
	- G. [A & D]
	- H. A, C & D
	- I. A, B, C & D 
9. Which of the following software process models can be a DIRECT mapping of the Deming cycle?
	1. A. Waterfall
	2. B. Spiral
	3. C. Incremental
	4. D. Scrum
	5. E. A & B
	6. F. C & D
	7. G. B & C
	8. H.[ B & D]
	9. I. B, C & D <- [I Choose]
10. Which of the following is an **incorrect** statement about variations?
	1. [A. Common cause variations are common across all processes]
	2. B. Special cause variations are outliner that alerts us for further analysis of their causes
	3. C. Special cause variations usually means opportunity for improvements
	4. D. Common cause variations are inherent in the system <-[ I Choose]
11. In test cause specifications, which key word should we use when we are evaluating whether a precondition of a requirement is satisfied?
	1. A. Verify <- [I choose]
	2. B. Ensure
	3. C. [Observe]
	4. D. Assert
12. Which of the following statement about control chart is NOT true?
	1. A. it is difficult to apply control chart directly in software lifecycle due to the special features of software process <- [I choose]
	2. B. If a sample falls under the lower control limit, the process is out of control
	3. C. [If all 4 stability tests are passed, it indicates there is no problem of the process under monitor]
	4. D. We need to monitor the deviations of both the center and variation of each sample to decide whether a process is under control
13. Which of the following tools can be used for problem identification?
	1. A. Bar Chart
	2. B. Run Chart
	3. C. Fishbone Diagram
	4. D. [All of the above]
14. Both bar chart and histogram can be used to organize data based on frequency of occurance. Which one should you use to describle U.S. household incomes?
	1. A. Bar Chart
	2. B. [Histogram]
15. In statistical process control, how can we **control** and **improve** a process by **analyzing variations**? Use  few sentences to describe the general process.
	1. **Control**
		1. [In SPC, we control a process by identifing variability, and determining if it is common or special cause, then we adjust our recording as needed]
	2. **Improve**
		1. [ By taking those special case variations, we can then construct a cause-effect diagram to determine the factors in the problem, and work with all parts of a software development team to find a solution.]
16. Given the following x-bar chart, is the monitored process stable? Why?
	1. [The monitored process is not stable.. This is because it fails the 3rd stability detection rule: sample number 14, 18, 19 and 20 are all > 1 sigma from the centerline, and they satisfy the 4/5 successive values on the same side condition.]
		1. Note: Test 3 was not the only test that failed. Double check the chart later to figure out why
	2. ![[X-bar chart.png]]
17. A game company was planning on releasing a new generation of their most popular video game in January 2022. Unfortunately, the company has been seeing a **big delay in release**. The game release was rescheduled twice, first to July 2022 and now again to January 2023. They hire you as a consultant to try and figure out the causes
	1. Which type of Cause-Effect diagram would you choose and what are the benefits of the chosen type of CE diagram?
		1. [A dispersion analysis CE diagram would be most appropriate. This diagram organizes and relates different factors that can point to the root cause]
		2. `Note: dispersion analysis was marked incorrect, but not he rest of the question`
	2. Who should you invite to the causal analysis session?
		1. [Developers, managers, and project planners should all be invited to the session to get a solid voerview of all perspectives of the development process]
	3. Construct a CE diagram to identify possible causes of a delayed game delivery based on people's roles in 2). Feel free to make assumptions:
		1. ![[CE Diagram.png]]