# 10/17/22 - 15 - QA Organization and Test Doc
- ### Outline
	- QA organizational structure
	- Test Documents
		- Test plan
		- Test specifications
	- Good requirements to test
- ### Independent QA Organization
	- ![[Pasted image 20221023161226.png]]
	- QA organizations are generally separate from organizations such as Development, Marketing, and Sales and report to different VPs
	- This independence supports:
		- Decision making that primarily reflect a company's software quality goals rather than developement, financial, marketing, ... goals
- ### QA Roles in the Lifecycle
	- **Process cops:**
		- is the process followed? PDCA?
	- **Requirements and/or use cases:**
		- Current, validated and formally documented?
	- **Test cases:**
		- generated and reviewed after requirements are confirmed!
	- **Configuration Management**
		- QA owns the code once it's baselined!
	- **Build Control:**
		- clean and controlled process and environment
		- documented and repeatable?
		- CI/DC
	- During the testing process:
		- **Unit testing** (white-box): done by developers, audited by QA
		- **Integration** testing
		- **System** testing
		- **Acceptance testing:** written by the customer
		- **TDD**: assist customer to produce automated acceptance tests.
		- **Simulators/Test Harness:** build and maintain
		- **STE** (special test equipment)
- ### Test Document Types
	- Test Plan
		- Test goals, overall plans, schedules, special equipment and resources 
		- But not the test cases!
		- Completed during **project planning** phase
	- Test specification
		- Detailed test cases
		- Created during **design** phase after requirement is detailed
		- Completed during **early implementation** phase
		- Evolve during **implementation** phases
	- Test plan and specification are often merged into one test document
- ### Test Document Styles
		- Inclusive test documents:
			- chapters for everything from unit tests to acceptance tests
		- Individual test documents
			- Each software phase has its own test plan and specification
			- Perhaps an overview document to link all phases together 
		- Unit test documents
			- Sometimes it is a part of a detailed design document
- ### Test Document Template
	- IEEE Std 829-2008: Standard for Software Test Documentation
	- Some highlights:
		- Figure 1: how to use this standard.  
		- Section 4: Integrity Level: indicates the relative importance of software to its stakeholders. (Examples: 1: games; 4: Aviation software)  
	- Section 5.4 Process-development:  
		- what testing tasks are necessary in each development activity  
	- Table 3: testing tasks necessary for different integrity levels  
	- Section 8-13: detailed templates
- ### Test Document for Phone Calling
	- 1 Intruduction
		- 1.1 Purpose
		- 1.2 Setup
			- 1.2.1 Software and hardware installation
			- 1.2.2 Phone number setup
	- 2 Requirements 
		- Provide reference to external requirements specification document
	- 3 Test Cases
		- 3.1 Test Case 1: Test dial tone
			- 3.1.1 Purpose
				- Verify that requirements R001 and R002 have been satisfied and the normal dial and off hook warning tones are functional
			- 3.1.2 Estimated Test Time
				- 15 minutes
			- 3.1.3 Setup
				- The basic setup has been done (see section 1.2). Two stopwatches will be needed.
			- 3.1.4 Execution
| Steps  | Results (Pass / Fail) / Comments |
|--------|----------------------------------|
| Step   | Comments                         |
| Verify | (Pass / Fail)                    |
			- 3.1.5 Expected Results
				- Describe passing requirements for each verify step
			- 3.1.6 Results Summary
| Date / Time | Build | Tester | Actual Time | Pass/Fail | Remarks |
|-------------|-------|--------|-------------|-----------|---------|
|             |       |        |             |           |         |
			- 3.1.7 Teardown
		- 3.2
			- ....
	- 4 Summary of All Tests
		| Test Case | Rqmt Tested | Pass/Fails | Date Test Run |
		| --------- | ----------- | ---------- | ------------- |
		|           |             |            |               |
	- 5 Traceability to Requirement
		| Requirement | Test Case(s) | Notes |
		| ----------- | ------------ | ----- |
		| R001        | 1            | n/a   |
		| R002        | 2            | n/a   |
- ### Forms of Reuqirement Spec
	- Raw individual statements
	- Requirement Specifications
		- Hierarchical structure starting from the top
			- System -> subsystems -> major 
- ### SMART Requirement
	- ##### Smart Requirements 
		- **Speicific**
			- Valid: meets user expectations and needs
			- Complete and non-ambiguous: Where interperation is necessary, there will be different interpertations
				- "I saw the main in the park with a telescope"
			- Technical level: User technical terms, alogrithms, business logic need to be clearly defined (genrally in a glossary), C1
		- **Measurable**
			- Testable: The system can test and have very little uncertainty whether the requirement was satisfied or not satisfied. (A1 or A2) and (B1 or B2)
		- **Attainable** (Achieveable, Actionable, Appropriate)
			- Non-conflicting: one requirement should not conflict with another requirement (B2 or B3)
			- Actually needed: not just wishes
		- **Reliastic**
		- **Time Bound** (Timely, Traceable)
			- Well organized: cross reference related requirement
	- ##### Examples of Requirements
		- A1: The system shall have a wonderful users' interface
		- A2: The under interface shall reuire four or frewer mouse clicks to initate any transcation and follow Company XYZ's user interface standards.
		- A3: It would be nice to have white littering on a blue background.
		- B1: The system shall deliver rapid responses to user queries
		- B2: The system shall deliver 98% of all users queries within 3 seconds while sustaining transcation rates of 10,000 transactions per second on target hardware
		- B3: The system shall maintain a maximum transaction rate of 9,000 transactions per second
		- C1: The control mechanism shall use E.W.M.A. (with a lambda of 0.3), and L.C.L. and U.C.L. of 99.98 and 101.23, respectivly