# 10/10/22 - 13 - Quality Management
# Quality Management
- ### The Red Bead Experiment
	- 6 willing workers
	- 2 QA engineers
	- 1 inspector
	- 1 Recorder
	- **Take 20 beads out from the pool with minimum # of red beads!**
		- Will it help if we 
			- enhance rigdid and precise procedure?
			- put motivating slogans around the room?
			- set numerical objectives?
			- reward by salary increase and punish by firing?
	- **Lessons Learned**
		- It’s the system, not the workers.  
		- Management owns the system and quality is the outcome of the system -> quality must start with management.  
		- Rigid and precise procedures are not sufficient to produce the desired quality.  
		- Extrinsic motivations is not effective.  
		- Numerical goals and production standards can be meaningless.  
		- By using rewards and punishment, management was tampering with a stable system.  
		- And many more...
- ### Demming's 14 Quality Principles
	1. Create a constant purpose toward improvement  
	2. Adopt the new philosophy  
	3. Cease dependence on mass inspection  
	4. End lowest tender contracts (Use a single supplier for any one item)  
	5. Improve every process constantly and forever  
	6. Institute training on the job  
	7. Institute leadership  
	8. Drive out fear  
	9. Break down barriers between departments  
	10. Eliminate exhortations (Get rid of unclear slogans)  
	11. Eliminate arbitrary numerical targets  
	12. Permit pride of workmanship  
	13. Encourage education  
	14. Top management commitment and action
- ### Demming's Cycle
	- **Plan**: define your objectives and determine how to achieve them  
	- **Do**: execute your plan and collect data  
	- **Check**: evaluate results and look for deviations.  
	- **Act**: identify root causes of deviations; decide what need to be improved  
	- **Continuous improvement**: successive PDCA cycles  
		- each one refining the process or product more.  
	- The “wheel within a wheel”: the relationship between strategic management and business unit management
	- ![[Pasted image 20221022143745.png]]
- ### Applying Deming's Cycle: Waterfall
	- Waterfall model:  
		- PDCA can be loosely applied  
			- P, D, C, A at each phase  
			- Don’t progress to the next phase until we are satisfied that we have achieved the goals for the first phase.
	- ![[Pasted image 20221022144138.png]]
- ### Apply Deming Cycle: Spiral
	- Spiral Model:
		- ![[Pasted image 20221023160224.png]]
	- Very clear mapping of the Spiral model to the Deming Cycle
- ### Apply Deming Cycle to Agile Development
	- Natural mapping:  
		- Plan: sprint planning  
		- Do: sprint work  
		- Check: sprint review  
		- Act: sprint retrospective
- ### Summary 
	- SPC: process stability and capability  
	- 2 types of variations: common cause (chance) and special cause (assignable)  
	- SPC tools  
	- Deming’s 14 quality principles  
	- Apply Deming cycle to Software process models

![[Recording 20221010145154.webm]]