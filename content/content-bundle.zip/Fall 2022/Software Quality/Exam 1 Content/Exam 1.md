## Definitions
- Software
	- Computer programs, procedures & docs + data to operation of computer system
- 3 Components
	- Code
	- Docs
	- Data
- Quality
	- Degree to which software satisfies needs under conditions
## Quality Characteristics
- Majority of defects are introuduced in earlier phases
	- ![[Pasted image 20221003120007.png]]
- Relative cost of fixing defects
	- ![[Pasted image 20221003120031.png]]
- 8 Product quality characteristics
	1. functional suitability
		1. completeness
		2. correctness
		3. appropriateness
	2. reliability
		1. Maturnity
		2. Availability
		3. Fault toleranceSS
		4. Recoverability
	3. performance efficiency
		1. Time behavior
		2. Resource utilization
		3. Capacity
	4. usability
		1. Appropriateness recognizability
		2. Learnability
		3. Operability
		4. User error protection
		5. User interface asthetics
		6. Accessibility
	5. security
		1. Confidentiality
		2. Integrity
		3. Non-repudation
		4. Accountability
		5. Authenticity
	6. compatibility
		1. Co-existence
		2. Interoperability
	7. Maintainability
		1. Modularity
		2. Reusability
		3. Modifability
		4. Analysability
		5. Modifiability
		6. Testability
	8. portability
		1. Adapability
		2. Replaceability
## Software Quality Assurance
- Components of quality assurance  
	- Pre-project  
	- Project life cycle activities assessment  
	- Infrastructure error prevention and improvement  
	- Software quality management  
	- Standardization, certification and SQA system assessment  
	- Organizing for SQA - the human components
- Contract review
	- Agreements on functional specifications, budget and schedule.  
	- Evaluate the capacity of professional staff and customers  
	- Evaluate risks  
- Development and quality plans (Integrated)
	- Development plan  
		- Schedules  
		- Required manpower and hardware resources  
		- risk evaluations  
		- organizational issues  
		- project methodology, development tools  
		- software reuse plan  
- Software quality assurance plan (SQAP)  
	- Quality goals  
	- Criteria for starting and ending each project stage  
	- SQA activities.
- Project life cycle component  
	- Reviews  
		- Formal design reviews (DR)  
		- Peer reviews: inspections and walkthroughs  
- Software testing  
- Software maintenance  
	- Corrective maintenance  
	- Adaptive maintenance  
	- Functionality improvement maintenance  
	- Similar SQA components as for the development process  
- Assurance of the quality of the external participant’s work
## SQA Concepts
- Quality costs = Prevention costs + Detection and Appraisal costs + Failure costs
	- Internal failure costs
	- External failure costs
- Cost of Quality (COQ)
	- Refers to the cost of correcting defect once found
- Quality Control
	- Detection & Product
- Quality assurance 
	- Prevention
	- Proess
- Software Verification
	- Are we building thr product right?
- Software Validation
	- Are we building the right product?
- ![[Pasted image 20221003120438.png]]

## Software Configuration Management - 1
- SCM
	- Managing the evolution of software systems
- Identification  
	- Identify configurations, configuration items and baselines  
- Control:  
	- Release and change control  
	- Build management  
	- Defect tracking  
- Status accounting  
	- Record, report status of the development process  
- Audit and review
	- Validate completeness
- Software configuration item (SCI)
	- Approved unit of code/docs/hardware for config management 
	- Treated as distinct entity in SCM process
	- Unique and consistent name
- Docs
	- plan, specs, test plan, etc
- Software Code
- Data files
- Software dev tools 
- SCI version
	- approved state of SCI
- Software configuration version
	- approved selected set of doced SCI versions that constitute a software system or document
	- releaded accourding to cited procedures
- Configuration baseline 
	- fixed reference config established by defining and recording SCI @ milestone
- config baseline serves point for departure for future SCI changes
- ![[Pasted image 20221003121440.png]]
## SCM - 2
- Config Change Control
	- consistent state & enforcs access control 
- Change Control
	- process for proposing, evaluating, changing existing system
- Types of changes
	- Defects fixing
	- Enhancement
	- Ports
- Configuration Control Board
	- CCB is a committee of many stakeholders
		- Sales, marketing
		- dev
		- quality assurance
		- customer support
	- Standards Change Request Form
- Configuration status accounting
	- Accounting is the change process
- Audit
	- planned and documented activity to ensure compliance with procedures
- Informal audits performed @ key phases of the software life cycle -> Reviews
- Formal config audit FCA
	- Validate system against the requirement
- physical config audit PCA
	- Whether the design and reference docs represent the software that was built

## SCM - 3
- Workspace
	- Per team member
	- Designed to prevent interference
	- Check in/check out
- Centralized Version Control
	- Client Server Model
		- RCS, CVS, SourceSafe, Subversion
- Versioning models
	- File-Sharing problem
	- Versioning models 
		- Lock-Modify-Unlock
		- Copy-Modify-Merge
	- Conflict
		- Overlap may occur -> conflict
	- Deltas
		- Store only changes to file
		- Delta
			- Differencees between revisions 
				- Forward deltas (SCCS, svn(FSFS))
					- First to last
				- Backward deltas (RCS, svn(BDB), git)
					- Last to first
		- snapshot
			- fully copy of an artifact
- Distributed version control (DVC)
	- Git
		- peer to peer
		- pull and push
- Benefit of DVC
	- Entire product is local
	- Faster
	- resistant to server failure

## SCM - 4
- Branching strategies
	- releasse
	- project phase
	- task
	- component
	- technology
- Trade off between productivity and risk

## SCM - 5
- CI/CD
	- Continuous integration / Continous deployment
	- Pipeline automates software delivery process
- Elements in a pipeline
	- Stages
	- Jobs
	- Image
	- Artifacts
	- Variables
	- Script
	- Dependencies
- DevOps
	- ![[Pasted image 20221003123553.png]]