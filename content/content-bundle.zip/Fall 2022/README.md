## Table of Contents - Fall 2022
- Astronomy 1340 [[School/Fall 2022/Astronomy/README]]
- Microeconomics 2230 [[School/Fall 2022/Econ/README]]
- International Management 4140 [[School/Fall 2022/International Business/README]]
- Senior Design Project 4340 [[School/Fall 2022/Senior Design Project/README]]
- Software Quality 3730 [[School/Fall 2022/Software Quality/README]]