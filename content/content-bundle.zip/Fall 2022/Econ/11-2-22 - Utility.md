- Example: Pizza and Pepsi
	- Two goods, pizza and Pepsi
		- Pizza is $2 per slicce
		- Pepsi is $1 per can
		- You have $10 to spend
	- Consumption of pizza and Pepsi both exhibit diminishing marginal utility
		- If I consume pizz, MU_pizza falls
		- If I consume Pepsi MU_Pepsi falls
	- Do prices ever change?
		- Prices can change
- ### More than two Goods
	- In the consumer optimum, the marginal utility per dollar was equal for both goods. **At the last dollar spent**, we had
		- $$ {MU_{Pizza}}/{Price_{Pizza}} = {MU_{Pepsi}}/{Price_{Pepsi}}$$
- ### Optimization in Real Life
	- In real life, does it always work with **perfect exact equality**?
		- nah, but we can get close
| **$2 Beer** | **MU**           | **MU / $** | **$2 Pizza** | **MU**           | **MU / $** |
| ------- | ------------ | ------ | -------- | ------------ | ------ |
| 1       | 25 - 0 = 25  | 25/2   | 4        | 50 - 45 = 5  | 5/2    |
| 2       | 45 - 25 = 20 | 10     | 3        | 45 - 35 = 10 | 5      |
| 3       | 65 - 45 = 15 | 15/2   | 2        | 35 - 20 = 15 | 15/2   |
| 4       | 65 - 60 = 5  | 5/2    | 1        | 20 - 0 = 20  | 10     |
![[Pasted image 20221102094012.png]]
| $5 DVD | MU  | MU / $     | $10 Pizza | MU  | MU / $      | Total Utility |
| ------ | --- | ---------- | --------- | --- | ----------- | ------------- |
| 1      | 150 | 150/5 = 30 | 6         | 60  | 60/10 = 6   | 210           |
| 2      | 120 | 120/5 = 24 | 5         | 100 | 100/10 = 10 | 220           |
| 3      | 100 | 100/5 = 20 | 4         | 120 | 120/10 = 12 | 220           |
| 4      | 90  | 90/5 = 18  | 3         | 150 | 150/10 = 15 | 240           |
| 5      | 60  | 60/5 = 12  | 2         | 180 | 180/10 = 18 | 240           |
| 6      | 40  | 40/5 = 8   | 1         | 200 | 200/10 = 20 | 240           |

- 4 DVD and 2 Pizza and all money is spent

- Lisa spends all her income on pizzas and DVDs. The above table shows Lisa's marginal utility for pizza and marginal utility for DVDs. If the price of a pizza is $10, the price of a DVD is $10, and Lisa has $40 to spend on the two goods, what combination of pizza and DVDs will maximize her utility?

| $10 DVD | MU  | MU / $      | $10 Pizza | MU  | MU / $      | Total Utility |
| ------- | --- | ----------- | --------- | --- | ----------- | ------------- |
| 1       | 150 | 150/10 = 15 | 6         | 60  | 60/10 = 6   |               | 
| 2       | 120 | 120/10 = 12 | 5         | 100 | 100/10 = 10 |               |
| 3       | 100 | 100/10 = 10 | 4         | 120 | 120/10 = 12 |               |
| 4       | 90  | 90/10 = 9   | 3         | 150 | 150/10 = 15 |               |
| 5       | 60  | 60/10 = 6   | 2         | 180 | 180/10 = 18 |               |
| 6       | 40  | 40/10 = 4   | 1         | 200 | 200/10 = 20 |               |
 
- 3 Pizza and 2 DVDs