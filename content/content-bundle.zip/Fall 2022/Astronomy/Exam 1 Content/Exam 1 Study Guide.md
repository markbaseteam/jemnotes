- ### Size scales of objects in the Universe
	- Scale of the Universe
		1. Pluto
		2. Moon
		3. Earth
		4. Sun
		5. Solar System
		6. Solar Neighborhood
		7. Milky Way Galaxy
		8. Local Galactic Group
		9. Virgo Supercluster
		10. Laniakea supercluster
		11. Local Superclusters
		12. Observable universe
- ### Sky motions  
	- **Celestial sphere**  
		- Be aware of what direction you’re facing  
		- Everything rises (or gets higher) in the east and sets (or gets lower) in the west  
		- 1 full cycle is 24 hours  
		- This cycle happens because the Earth rotates  
		- More circumpolar stars the closer to a pole you go  
		- Fewer circumpolar stars the closer to the equator you go
	- **The motion of the Sun in the sky**
		- Rotates around the ecliptic every 365.25 days
		- Stars behind sun shift west every day
		- 13 Zodiac constellations
		- One constellation per month
	- **Motion of stars**
		- Stars rise in the East and set in the West
		- Cirumpolar stars
			- Never set
			- Rotate around the closest pole counter-clockwise
	- **Eclipses**
		- Lunar
			- Earth passes between the Moon and the Sun
			- Full Moon
		- Solar
			- Moon passes between the Earth and the Sun
			- New Moon
- ### Seasons 
	- Identifying seasons, what causes them  
		- Tilt of the Earth toward Sun = More Sunlight Longer = Summer
		- Tilt of the Earth away Sun = Less Sunlight Shorter = Winter
		- Distance from sun does not matter
	- Seasons on planets with different tilts  
		- Venus, Mercury, Jupiter: no seasons (no axis tilt)  
		- Uranus: extreme seasons
- ### Historical astronomy  
	- **Geocentric**
		- Earth is at the center and does not move
		- The Sun, Moon, planets, and stars revolve around the Earth
		- Evidence
			- We don’t feel like we’re moving
			- The stars don’t show parallax
			- The sky pretty predictably follows this pattern if you don’t have access to tools to make really detailed measurements
	- **Heliocentric**
		- The Sun, Moon, and planets all moved on perfect circles around the Earth.
		- This model does not explain the retrograde motion of Mars and other planets.
		- To explain retrograde motion, planets needed to move on a circular epicycle.
		- Earth was slightly offset from center of circular orbits in order to match observations.
		- Planets had varying speeds.
	- **Kepler’s laws  
		1. The orbits of the planets are ellipses with the Sun at one focus.  
			- Some comets and dward planets ave eccentric orbits
		2. A line from a planet to the sun sweeps over equal areas in equal intervals of time.
			- A planet moves faster when it is closer to the Sun and slower when it is farther away.
		3. A planet’s orbital period squared is proportional to its average distance from the sun cubed:
			- P^(2) Years = a^3(AU)
			- Higher distance = longer orbital period
			- Period not dependent on planet mass
			- Holds true for all objects in orbit
	- **Newton's Laws of Motion**
		1. An object remains at rest or moves in a straight line at a constant speed unless acted upon by an outside (net) force.
		2. (net) Force = mass x acceleration
		3. Whenever one object exerts a force on a second object, the second object exerts an equal and opposite force on the first object
	- **Newton's Laws of Gravitation**
		- f_(grav) = (Gm_(1)m_(2))/d^2 
		- Larger objects = greater force
		- Closer objects = greater force
	- **Theory in the natural sciences**
		- **Facts** are **proven true things** and **theories** are **unproven educated guesses**.  
		- Theories are how we explain the facts that we observe, and how we put those facts together to better understand the universe.  
		- Facts give us who/what/where/when. Theories give us why and how.