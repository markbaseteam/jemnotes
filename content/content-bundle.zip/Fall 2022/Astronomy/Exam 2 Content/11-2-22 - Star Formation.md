- ### Stages of Star Formation
	1. The interstellar medium - gas and dust
	2. Molecular Cloud forms - dense and cold
	3. Densest parts of cloud collapse
	4. This core gets denser and hotter
	5. The core becomes a Protostar
	6. The protostar gets hot enough for fusion in its center and becomes a main sequence star
	7. repeat

	- To get from molecular clouds to stars, the densest parts of molecular cloud need to continue to collapse
	- Each molecular core collapses due to gravity from its own mass. These cores are too cold to support their mass, so they continue to collapse and heat up
	- As the cores collapse they begin to spin faster, eventually forming a protostar surrounded by an eccretion disk of material.
	- The jet blows away the remaining gas and dust surrounding the ptotostar
	- The protostar continues to collapse and heat up
	- Eventually the core of the protostar will be hot enough for fusion to occur and then we have a main sequence star where gravity pushing inward and energy pushing outward are balanced
	- ### What happens if a protostar never gets hot enough for nuclear fusion
		- Objects with less thatn 0.08 solar masses will *never* get hot enough for fusion to occur in their cores
		- These are called browndwarfs
		- Theorized in the 1960's by Shiv Kumar, first discovered in 1904 by Rafeel Rebolo, Maria Rosa Zapatero Osorio, and Eduardo Martin
		- They glow only from internal heat from their contraction during formation; some can fuse deuterium to produce some energy
		- They have masses greater than 13 times the mass of jupiter and less than M-type stars
- ### Protostars on the H-R Diagram
	- As stars form they move on the HR diagram
	- The core is always getting hotter.
	- High-mass stars remain bright, but heat up as they form
	- Low-mass stars stay at the same temperature (until fusion starts), but get fainter as they form
- ### Formation times
	- Just as massive stars have short lifetimes, they also form quickly 